
package system.configurator.users.metrics;

import java.io.Serializable;

/**
 *
 * @author ali
 */
public class CPUMetrics implements Serializable {

    private static final long serialVersionUID = 13960921L;

    private double parallel;
    private double power;
    private double cost;
    private double onboardGraphic;

    public CPUMetrics() {
    }

    public CPUMetrics(double parallel, double power, double cost, double onboardGraphic) {
        this.parallel = parallel;
        this.power = power;
        this.cost = cost;
        this.onboardGraphic = onboardGraphic;
    }

    public double getParallel() {
        return parallel;
    }

    public void setParallel(double parallel) {
        this.parallel = parallel;
    }

    public double getPower() {
        return power;
    }

    public void setPower(double power) {
        this.power = power;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public double getOnboardGraphic() {
        return onboardGraphic;
    }

    public void setOnboardGraphic(double onboardGraphic) {
        this.onboardGraphic = onboardGraphic;
    }

}
