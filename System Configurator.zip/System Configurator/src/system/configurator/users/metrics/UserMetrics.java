/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package system.configurator.users.metrics;

import java.io.Serializable;
import system.configurator.model.UserChoice;

/**
 *
 * @author ali
 */
public class UserMetrics implements Serializable {

    private static final long serialVersionUID = 13960921L;

    private GPUMetrics gpuMetrics;
    private CPUMetrics cpuMetrics;
    private MotherboardMetrics motherboardMetrics;
    private RAMMetrics ramMetrics;
    private StorageMetrics storageMetrics;
    private UserChoice userChoice;

    public UserMetrics() {

    }

    public UserMetrics(GPUMetrics gpuMetrics, CPUMetrics cpuMetrics, MotherboardMetrics motherboardMetrics, RAMMetrics ramMetrics, StorageMetrics storageMetrics, UserChoice userChoice) {
        this.gpuMetrics = gpuMetrics;
        this.cpuMetrics = cpuMetrics;
        this.motherboardMetrics = motherboardMetrics;
        this.ramMetrics = ramMetrics;
        this.storageMetrics = storageMetrics;
        this.userChoice = userChoice;
    }

    public UserMetrics(GPUMetrics gpuMetrics, CPUMetrics cpuMetrics, MotherboardMetrics motherboardMetrics, RAMMetrics ramMetrics, StorageMetrics storageMetrics) {
        this.gpuMetrics = gpuMetrics;
        this.cpuMetrics = cpuMetrics;
        this.motherboardMetrics = motherboardMetrics;
        this.ramMetrics = ramMetrics;
        this.storageMetrics = storageMetrics;
    }

    public UserChoice getUserChoice() {
        return userChoice;
    }

    public void setUserChoice(UserChoice userChoice) {
        this.userChoice = userChoice;
    }

    public GPUMetrics getGpuMetrics() {
        return gpuMetrics;
    }

    public void setGpuMetrics(GPUMetrics gpuMetrics) {
        this.gpuMetrics = gpuMetrics;
    }

    public CPUMetrics getCpuMetrics() {
        return cpuMetrics;
    }

    public void setCpuMetrics(CPUMetrics cpuMetrics) {
        this.cpuMetrics = cpuMetrics;
    }

    public MotherboardMetrics getMotherboardMetrics() {
        return motherboardMetrics;
    }

    public void setMotherboardMetrics(MotherboardMetrics motherboardMetrics) {
        this.motherboardMetrics = motherboardMetrics;
    }

    public RAMMetrics getRamMetrics() {
        return ramMetrics;
    }

    public void setRamMetrics(RAMMetrics ramMetrics) {
        this.ramMetrics = ramMetrics;
    }

    public StorageMetrics getStorageMetrics() {
        return storageMetrics;
    }

    public void setStorageMetrics(StorageMetrics storageMetrics) {
        this.storageMetrics = storageMetrics;
    }

}
