/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package system.configurator.users.metrics;

import java.io.Serializable;

/**
 *
 * @author ali
 */
public class StorageMetrics implements Serializable {

    private static final long serialVersionUID = 13960921L;

    private double speed;
    private double space;
    private double reliability;
    private double cost;

    public StorageMetrics() {
    }

    public StorageMetrics(double speed, double space, double reliability, double cost) {
        this.speed = speed;
        this.space = space;
        this.reliability = reliability;
        this.cost = cost;
    }

    public double getSpeed() {
        return speed;
    }

    public void setSpeed(double speed) {
        this.speed = speed;
    }

    public double getSpace() {
        return space;
    }

    public void setSpace(double space) {
        this.space = space;
    }

    public double getReliability() {
        return reliability;
    }

    public void setReliability(double reliability) {
        this.reliability = reliability;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

}
