/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package system.configurator.users.metrics;

import java.io.Serializable;

/**
 *
 * @author ali
 */
public class RAMMetrics implements Serializable {

    private static final long serialVersionUID = 13960921L;

    private double slot;
    private double cost;
    private double speed;
    private double space;

    public RAMMetrics() {
    }

    public RAMMetrics(double slot, double cost, double speed, double space) {
        this.slot = slot;
        this.cost = cost;
        this.speed = speed;
        this.space = space;
    }

    public double getSlot() {
        return slot;
    }

    public void setSlot(double slot) {
        this.slot = slot;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public double getSpeed() {
        return speed;
    }

    public void setSpeed(double speed) {
        this.speed = speed;
    }

    public double getSpace() {
        return space;
    }

    public void setSpace(double space) {
        this.space = space;
    }

}
