/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package system.configurator.users.metrics;

import java.io.Serializable;

/**
 *
 * @author ali
 */
public class MotherboardMetrics implements Serializable {

    private static final long serialVersionUID = 13960921L;

    private double extend;
    private double power;
    private double cost;

    public MotherboardMetrics() {
    }

    public MotherboardMetrics(double extend, double power, double cost) {
        this.extend = extend;
        this.power = power;
        this.cost = cost;
    }

    public double getExtend() {
        return extend;
    }

    public void setExtend(double extend) {
        this.extend = extend;
    }

    public double getPower() {
        return power;
    }

    public void setPower(double power) {
        this.power = power;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

}
