/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package system.configurator.model;

import java.io.Serializable;

/**
 *
 * @author ali
 */
public class ConfiguredSystem implements Serializable {
    private static final long serialVersionUID = 13960921L;
    private GPU gpu;
    private CPU cpu;
    private Motherboard motherboard;
    private RAM ram;
    private Storage storage;
    private double score;

    private double price;

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
    
    public ConfiguredSystem() {
    }

    public ConfiguredSystem(GPU gpu, CPU cpu, Motherboard motherboard, RAM ram, Storage storage) {
        this.gpu = gpu;
        this.cpu = cpu;
        this.motherboard = motherboard;
        this.ram = ram;
        this.storage = storage;
    }

    public double getScore() {
        return score;
    }

    public void setScore(double score) {
        this.score = score;
    }

    public GPU getGpu() {
        return gpu;
    }

    public void setGpu(GPU gpu) {
        this.gpu = gpu;
    }

    public CPU getCpu() {
        return cpu;
    }

    public void setCpu(CPU cpu) {
        this.cpu = cpu;
    }

    public Motherboard getMotherboard() {
        return motherboard;
    }

    public void setMotherboard(Motherboard motherboard) {
        this.motherboard = motherboard;
    }

    public RAM getRam() {
        return ram;
    }

    public void setRam(RAM ram) {
        this.ram = ram;
    }

    public Storage getStorage() {
        return storage;
    }

    public void setStorage(Storage storage) {
        this.storage = storage;
    }
    
    
}
