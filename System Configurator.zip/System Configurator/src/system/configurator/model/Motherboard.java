package system.configurator.model;

import java.io.Serializable;
import java.util.List;
import system.configurator.helpers.ScoreCalculator;
import system.configurator.users.metrics.MotherboardMetrics;

public class Motherboard implements Serializable {

    private static final long serialVersionUID = 13960921L;

    private String Name;
    private double CountOfMemorySlot;
    private String KindOfSocketProcessor;
    private String Bios;
    private List<String> KindOfMemorySupported;
    private boolean XMP;
    private double MAXOfMemorySupported;
    private boolean pciExpressSlot;

    private boolean crossFireSupport; // Boolean
    private boolean sliSupport;
    private boolean SATA3Supported;
    private boolean M2ConnectorSupported;
    private double CountOfPorts;
    private double Price;
    private MotherboardMetrics motherboardMetrics;

    private double motherboardScore;

    public boolean isPciExpressSlot() {
        return pciExpressSlot;
    }

    public void setPciExpressSlot(boolean pciExpressSlot) {
        this.pciExpressSlot = pciExpressSlot;
    }

    public double getMotherboardScore() {
        return motherboardScore;
    }

    public void calculateMotherboardScore(MotherboardMetrics userMotherboardMetrics) {
        this.motherboardScore = ScoreCalculator.
                motherboardScoreCalculator(motherboardMetrics, userMotherboardMetrics);
    }

    public Motherboard() {
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public double getCountOfMemorySlot() {
        return CountOfMemorySlot;
    }

    public void setCountOfMemorySlot(double CountOfMemorySlot) {
        this.CountOfMemorySlot = CountOfMemorySlot;
    }

    public String getKindOfSocketProcessor() {
        return KindOfSocketProcessor;
    }

    public void setKindOfSocketProcessor(String KindOfSocketProcessor) {
        this.KindOfSocketProcessor = KindOfSocketProcessor;
    }

    public String getBios() {
        return Bios;
    }

    public void setBios(String Bios) {
        this.Bios = Bios;
    }

    public List<String> getKindOfMemorySupported() {
        return KindOfMemorySupported;
    }

    public void setKindOfMemorySupported(List<String> KindOfMemorySupported) {
        this.KindOfMemorySupported = KindOfMemorySupported;
    }

    public boolean getXMP() {
        return XMP;
    }

    public void setXMP(boolean XMP) {
        this.XMP = XMP;
    }

    public double getMAXOfMemorySupported() {
        return MAXOfMemorySupported;
    }

    public void setMAXOfMemorySupported(double MAXOfMemorySupported) {
        this.MAXOfMemorySupported = MAXOfMemorySupported;
    }

    public boolean getCountOfCrossFire() {
        return crossFireSupport;
    }

    public void setCountOfCrossFire(boolean CountOfCrossFire) {
        this.crossFireSupport = CountOfCrossFire;
    }

    public boolean getSATA3Supported() {
        return SATA3Supported;
    }

    public void setSATA3Supported(boolean SATA3Supported) {
        this.SATA3Supported = SATA3Supported;
    }

    public boolean getM2ConnectorSupported() {
        return M2ConnectorSupported;
    }

    public void setM2ConnectorSupported(boolean M2ConnectorSupported) {
        this.M2ConnectorSupported = M2ConnectorSupported;
    }

    public double getCountOfPorts() {
        return CountOfPorts;
    }

    public void setCountOfPorts(double CountOfPorts) {
        this.CountOfPorts = CountOfPorts;
    }

    public double getPrice() {
        return Price;
    }

    public void setPrice(double Price) {
        this.Price = Price;
    }

    public MotherboardMetrics getMotherboardMetrics() {
        return motherboardMetrics;
    }

    public void setMotherboardMetrics(MotherboardMetrics motherboardMetrics) {
        this.motherboardMetrics = motherboardMetrics;
    }

    public boolean isCrossFireSupport() {
        return crossFireSupport;
    }

    public void setCrossFireSupport(boolean crossFireSupport) {
        this.crossFireSupport = crossFireSupport;
    }

    public boolean isSliSupport() {
        return sliSupport;
    }

    public void setSliSupport(boolean sliSupport) {
        this.sliSupport = sliSupport;
    }

    public boolean isCompatibleWithRAM(RAM ram) {

        return ram.getMemory() <= this.getMAXOfMemorySupported();
    }

    public boolean isCompatibleWithCPU(CPU cpu) {

        if (this.getKindOfSocketProcessor().equals(cpu.GetType())) {
            return true;
        }
        return false;
    }

    public boolean isCompatibleWithGPU(GPU gpu) {

        if ((this.getM2ConnectorSupported() && gpu.getM2ConnectorSupported())
                || (this.isPciExpressSlot() && gpu.getPCIExpress2And3Supported())) {

//            if ((this.isSliSupport() && gpu.getSLI())
//                    || (this.isCrossFireSupport() && gpu.getCrossFireSupported())) {

                return true;
//            }
        }
        return false;

    }

    public boolean isCompatibleWithStorage(Storage storage) {

        return this.getSATA3Supported() && this.getM2ConnectorSupported();
    }
}
