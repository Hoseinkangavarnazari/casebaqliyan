package system.configurator.model;

import java.io.Serializable;
import system.configurator.helpers.ScoreCalculator;
import system.configurator.users.metrics.StorageMetrics;

public class Storage implements Serializable {

    private static final long serialVersionUID = 13960921L;

    private String Name;
    private double space;
    private double Speed;
    private String KindOfDisk;
    private boolean sata3support;
    private boolean M2ConnectorSupported;
    private double price;
    private StorageMetrics storageMetrics;

    private double storageScore;

    public double getStorageScore() {
        return storageScore;
    }

    public void calculateStorageScore(StorageMetrics userStorageMetrics) {
        this.storageScore = ScoreCalculator.storageScoreCalculator(storageMetrics, userStorageMetrics);
    }

    public Storage() {
    }

    public Storage(String Name, double space, double Speed, String KindOfDisk, boolean M2ConnectorSupported, double price, StorageMetrics storageMetrics) {
        this.Name = Name;
        this.space = space;
        this.Speed = Speed;
        this.KindOfDisk = KindOfDisk;
        this.M2ConnectorSupported = M2ConnectorSupported;
        this.price = price;
        this.storageMetrics = storageMetrics;
    }

    public Storage(String Name, double space, double Speed, String KindOfDisk,
            boolean M2ConnectorSupported, String Price) {
        this.Name = Name;
        this.space = space;
        this.Speed = Speed;
        this.KindOfDisk = KindOfDisk;
        this.M2ConnectorSupported = M2ConnectorSupported;
    }

    public StorageMetrics getStorageMetrics() {
        return storageMetrics;
    }

    public void setStorageMetrics(StorageMetrics storageMetrics) {
        this.storageMetrics = storageMetrics;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public void setSpeed(double Speed) {
        this.Speed = Speed;
    }

    public void setKindOfDisk(String KindOfDisk) {
        this.KindOfDisk = KindOfDisk;
    }

    public void setM2ConnectorSupported(boolean M2ConnectorSupported) {
        this.M2ConnectorSupported = M2ConnectorSupported;
    }

    public String getName() {
        return Name;
    }

    public double getSpeed() {
        return Speed;
    }

    public String getKindOfDisk() {
        return KindOfDisk;
    }

    public boolean getM2ConnectorSupported() {
        return M2ConnectorSupported;
    }

    public boolean isSata3support() {
        return sata3support;
    }

    public void setSata3support(boolean sata3support) {
        this.sata3support = sata3support;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getSpace() {
        return space;
    }

    public void setSpace(double space) {
        this.space = space;
    }

}
