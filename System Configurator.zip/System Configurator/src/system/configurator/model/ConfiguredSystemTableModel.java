/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package system.configurator.model;

import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author ali
 */
public class ConfiguredSystemTableModel extends AbstractTableModel {

    List<ConfiguredSystem> dataList;
    private final String[] columnNames = {"CPU", "GPU", "RAM",
        "Storage", "Motherboard", "Price", "Score"};

    public ConfiguredSystemTableModel(List<ConfiguredSystem> dataList) {
        this.dataList = dataList;
    }

    @Override
    public int getRowCount() {
        return this.dataList.size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public String getColumnName(int columnIndex) {
        return columnNames[columnIndex];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        ConfiguredSystem configuredSystem = dataList.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return configuredSystem.getCpu().getName();
            case 1:
                return configuredSystem.getGpu().getName();
            case 2:
                return configuredSystem.getRam().getName();
            case 3:
                return configuredSystem.getStorage().getName();
            case 4:
                return configuredSystem.getMotherboard().getName();
            case 5:
                return configuredSystem.getPrice();
            case 6:
                return configuredSystem.getScore();
        }
        return null;
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        switch (columnIndex) {
            case 0:
                return String.class;
            case 1:
                return String.class;
            case 2:
                return String.class;
            case 3:
                return String.class;
            case 4:
                return String.class;
            case 5:
                return Double.class;
            case 6:
                return Double.class;
        }
        return null;
    }
}
