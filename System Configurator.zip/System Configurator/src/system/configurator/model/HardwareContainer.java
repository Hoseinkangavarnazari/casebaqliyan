/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package system.configurator.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import system.configurator.users.metrics.UserMetrics;

/**
 *
 * @author ali
 */
public class HardwareContainer implements Serializable {

    private static final long serialVersionUID = 13960921L;

    private List<GPU> listOfGPU;
    private List<CPU> listOfCPU;
    private List<Motherboard> listOMotherboards;
    private List<RAM> listOfRAM;
    private List<Storage> listOfStorages;

    public HardwareContainer() {
        this.listOMotherboards = new ArrayList<>();
        this.listOfCPU = new ArrayList<>();
        this.listOfGPU = new ArrayList<>();
        this.listOfRAM = new ArrayList<>();
        this.listOfStorages = new ArrayList<>();
    }

    public List<GPU> getListOfGPU() {
        return listOfGPU;
    }

    public void setListOfGPU(List<GPU> listOfGPU) {
        this.listOfGPU = listOfGPU;
    }

    public List<CPU> getListOfCPU() {
        return listOfCPU;
    }

    public void setListOfCPU(List<CPU> listOfCPU) {
        this.listOfCPU = listOfCPU;
    }

    public List<Motherboard> getListOMotherboards() {
        return listOMotherboards;
    }

    public void setListOMotherboards(List<Motherboard> listOMotherboards) {
        this.listOMotherboards = listOMotherboards;
    }

    public List<RAM> getListOfRAM() {
        return listOfRAM;
    }

    public void setListOfRAM(List<RAM> listOfRAM) {
        this.listOfRAM = listOfRAM;
    }

    public List<Storage> getListOfStorages() {
        return listOfStorages;
    }

    public void setListOfStorages(List<Storage> listOfStorages) {
        this.listOfStorages = listOfStorages;
    }

    // score calculation
    public void gpuListScoreCalculation(UserMetrics userMetrics) {

        listOfGPU.forEach((gpu) -> {
            gpu.calculateGpuScore(userMetrics.getGpuMetrics());
        });
    }

    public void cpuListScoreCalculation(UserMetrics userMetrics) {

        listOfCPU.forEach((cpu) -> {
            cpu.calculateCpuScore(userMetrics.getCpuMetrics());
        });
    }

    public void motherboardListScoreCalculation(UserMetrics userMetrics) {

        listOMotherboards.forEach((motherboard) -> {
            motherboard.calculateMotherboardScore(userMetrics.getMotherboardMetrics());
        });
    }

    public void ramListScoreCalculation(UserMetrics userMetrics) {

        listOfRAM.forEach((ram) -> {
            ram.calculateRamScore(userMetrics.getRamMetrics());
        });
    }

    public void storageListCalculation(UserMetrics userMetrics) {

        listOfStorages.forEach((storage) -> {
            storage.calculateStorageScore(userMetrics.getStorageMetrics());
        });
    }

//        Best Hardware Selection 
    public List<CPU> getThreeBestCPUs() {

        listOfCPU.sort((CPU o1, CPU o2) -> {
            return Double.compare(o1.getCpuScore(), o2.getCpuScore());
        });

        Collections.reverse(listOfCPU);
        List<CPU> bestCPU = new ArrayList<>(5);

        for (int i = 0; i < 5; i++) {
            bestCPU.add(listOfCPU.get(i));
        }

        return bestCPU;
    }

    public List<GPU> getThreeBestGPUs() {

        listOfGPU.sort((GPU o1, GPU o2) -> {
            return Double.compare(o1.getGpuScore(), o2.getGpuScore());
        });

        Collections.reverse(listOfGPU);
        List<GPU> bestGPU = new ArrayList<>(5);

        for (int i = 0; i < 5; i++) {
            bestGPU.add(listOfGPU.get(i));
        }

        return bestGPU;
    }

    public List<Motherboard> getThreeBestMotherboard() {

        listOMotherboards.sort((Motherboard o1, Motherboard o2) -> {
            return Double.compare(o1.getMotherboardScore(), o2.getMotherboardScore());
        });

        Collections.reverse(listOMotherboards);
        List<Motherboard> bestMotherboards = new ArrayList<>(5);

        for (int i = 0; i < 5; i++) {
            bestMotherboards.add(listOMotherboards.get(i));
        }

        return bestMotherboards;
    }

    public List<Storage> getThreeBestStorage() {

        listOfStorages.sort((Storage o1, Storage o2) -> {
            return Double.compare(o1.getStorageScore(), o2.getStorageScore());
        });

        Collections.reverse(listOfStorages);
        List<Storage> bestStorages = new ArrayList<>(5);

        for (int i = 0; i < 5; i++) {
            bestStorages.add(listOfStorages.get(i));
        }

        return bestStorages;
    }

    public List<RAM> getThreeBestRAMs() {

        listOfRAM.sort((RAM o1, RAM o2) -> {
            return Double.compare(o1.getRamScore(), o2.getRamScore());
        });

        Collections.reverse(listOfRAM);
        List<RAM> bestRAM = new ArrayList<>(5);

        for (int i = 0; i < 5; i++) {
            bestRAM.add(listOfRAM.get(i));
        }

        return bestRAM;
    }
}
