package system.configurator.model;

import java.io.Serializable;
import system.configurator.helpers.ScoreCalculator;
import system.configurator.users.metrics.CPUMetrics;

public class CPU implements Serializable {

    private static final long serialVersionUID = 13960921L;

    private String name;

    private String Type;
    private String ThreadAndCore;
    private String MAXOfFrequency;
    private String BaseOfFrequency;
    private String Cache;
    private double Price;
    private CPUMetrics cpuMetrics;

    private double cpuScore;

    public double getCpuScore() {
        return cpuScore;
    }

    public void calculateCpuScore(CPUMetrics userCPUMetrics) {
        this.cpuScore = ScoreCalculator.cpuScoreCalculator(cpuMetrics, userCPUMetrics);
    }

    public CPU(String name, String Type, String ThreadAndCore, String MAXOfFrequency, String BaseOfFrequency, String Cache, double Price, CPUMetrics cpuMetrics, double cpuScore) {
        this.name = name;
        this.Type = Type;
        this.ThreadAndCore = ThreadAndCore;
        this.MAXOfFrequency = MAXOfFrequency;
        this.BaseOfFrequency = BaseOfFrequency;
        this.Cache = Cache;
        this.Price = Price;
        this.cpuMetrics = cpuMetrics;
        this.cpuScore = cpuScore;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public CPU() {
    }

    public CPU(String Type, String ThreadAndCore, String MAXOfFrequency, String BaseOfFrequency, String Cache, double Price, CPUMetrics cpuMetrics) {
        this.Type = Type;
        this.ThreadAndCore = ThreadAndCore;
        this.MAXOfFrequency = MAXOfFrequency;
        this.BaseOfFrequency = BaseOfFrequency;
        this.Cache = Cache;
        this.Price = Price;
        this.cpuMetrics = cpuMetrics;
    }

    public CPU(String Type, String ThreadAndCore, String MAXOfFrequency, String BaseOfFrequency,
            String Cache, double Price) {
        this.Type = Type;
        this.ThreadAndCore = ThreadAndCore;
        this.MAXOfFrequency = MAXOfFrequency;
        this.BaseOfFrequency = BaseOfFrequency;
        this.Cache = Cache;
        this.Price = Price;
    }

    public String getType() {
        return Type;
    }

    public void setType(String Type) {
        this.Type = Type;
    }

    public String getThreadAndCore() {
        return ThreadAndCore;
    }

    public void setThreadAndCore(String ThreadAndCore) {
        this.ThreadAndCore = ThreadAndCore;
    }

    public String getMAXOfFrequency() {
        return MAXOfFrequency;
    }

    public void setMAXOfFrequency(String MAXOfFrequency) {
        this.MAXOfFrequency = MAXOfFrequency;
    }

    public String getBaseOfFrequency() {
        return BaseOfFrequency;
    }

    public void setBaseOfFrequency(String BaseOfFrequency) {
        this.BaseOfFrequency = BaseOfFrequency;
    }

    public String getCache() {
        return Cache;
    }

    public void setCache(String Cache) {
        this.Cache = Cache;
    }

    public double getPrice() {
        return Price;
    }

    public void setPrice(double Price) {
        this.Price = Price;
    }

    public CPUMetrics getCpuMetrics() {
        return cpuMetrics;
    }

    public void setCpuMetrics(CPUMetrics cpuMetrics) {
        this.cpuMetrics = cpuMetrics;
    }

    public void SetType(String Type) {
        this.Type = Type;
    }

    public void SetThreadAndCore(String ThreadAndCore) {
        this.ThreadAndCore = ThreadAndCore;
    }

    public void SetMAXOfFrequency(String MAXOfFrequency) {
        this.MAXOfFrequency = MAXOfFrequency;
    }

    public void SetBaseOfFrequency(String BaseOfFrequency) {
        this.BaseOfFrequency = BaseOfFrequency;
    }

    public void SetCache(String Cache) {
        this.Cache = Cache;
    }

    public String GetType() {
        return Type;
    }

    public String GetThreadAndCore() {
        return ThreadAndCore;
    }

    public String GetMAXOfFrequency() {
        return MAXOfFrequency;
    }

    public String GetBaseOfFrequency() {
        return BaseOfFrequency;
    }

    public String GetCache() {
        return Cache;
    }

}
