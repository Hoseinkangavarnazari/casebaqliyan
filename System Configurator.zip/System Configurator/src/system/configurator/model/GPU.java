package system.configurator.model;

import java.io.Serializable;
import system.configurator.helpers.ScoreCalculator;
import system.configurator.users.metrics.GPUMetrics;

public class GPU implements Serializable {

    private static final long serialVersionUID = 13960921L;

    private String Name;
    private double MuchOfMemory;
    private String KindOfMemory;
    private boolean M2ConnectorSupported;
    private boolean ParalelSupported;
    private String PowerOfProcessor;
    private boolean PCIExpress2And3Supported;
    private boolean CrossFireSupported;
    private boolean SLISupport;// boolean
    private double Price;
    private GPUMetrics gpuMetrics;

    private double gpuScore;

    public double getGpuScore() {
        return gpuScore;
    }

    public void calculateGpuScore(GPUMetrics userGPUMetrics) {
        this.gpuScore = ScoreCalculator.gpuScoreCalculator(gpuMetrics, userGPUMetrics);
    }

    public GPU() {
    }

    public GPU(String Name, double MuchOfMemory, String KindOfMemory, boolean M2ConnectorSupported, boolean ParalelSupported, String PowerOfProcessor, Boolean PCIExpress2And3Supported, Boolean CrossFireSupported, boolean SLI, double Price, GPUMetrics gpuMetrics, double gpuScore) {
        this.Name = Name;
        this.MuchOfMemory = MuchOfMemory;
        this.KindOfMemory = KindOfMemory;
        this.M2ConnectorSupported = M2ConnectorSupported;
        this.ParalelSupported = ParalelSupported;
        this.PowerOfProcessor = PowerOfProcessor;
        this.PCIExpress2And3Supported = PCIExpress2And3Supported;
        this.CrossFireSupported = CrossFireSupported;
        this.SLISupport = SLI;
        this.Price = Price;
        this.gpuMetrics = gpuMetrics;
        this.gpuScore = gpuScore;
    }

    public GPU(String Name, double MuchOfMemory, String KindOfMemory, boolean M2ConnectorSupported, Boolean ParalelSupported, String PowerOfProcessor, boolean PCIExpress2And3Supported, boolean CrossFireSupported, boolean SLI, double Price, GPUMetrics gpuMetrics) {
        this.Name = Name;
        this.MuchOfMemory = MuchOfMemory;
        this.KindOfMemory = KindOfMemory;
        this.M2ConnectorSupported = M2ConnectorSupported;
        this.ParalelSupported = ParalelSupported;
        this.PowerOfProcessor = PowerOfProcessor;
        this.PCIExpress2And3Supported = PCIExpress2And3Supported;
        this.CrossFireSupported = CrossFireSupported;
        this.SLISupport = SLI;
        this.Price = Price;
        this.gpuMetrics = gpuMetrics;
    }

    public GPU(String Name, double MuchOfMemory, String KindOfMemory, boolean M2ConnectorSupported,
            boolean ParalelSupported, String PowerOfProcessor, boolean PCIExpress2And3Supported,
            boolean CrossFireSupported, boolean SLI, double Price) {
        this.Name = Name;
        this.MuchOfMemory = MuchOfMemory;
        this.KindOfMemory = KindOfMemory;
        this.M2ConnectorSupported = M2ConnectorSupported;
        this.ParalelSupported = ParalelSupported;
        this.PowerOfProcessor = PowerOfProcessor;
        this.PCIExpress2And3Supported = PCIExpress2And3Supported;
        this.CrossFireSupported = CrossFireSupported;
        this.SLISupport = SLI;
        this.Price = Price;
    }

    public GPUMetrics getGpuMetrics() {
        return gpuMetrics;
    }

    public void setGpuMetrics(GPUMetrics gpuMetrics) {
        this.gpuMetrics = gpuMetrics;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public void setMuchOfMemory(double MuchOfMemory) {
        this.MuchOfMemory = MuchOfMemory;
    }

    public void setKindOfMemory(String KindOfMemory) {
        this.KindOfMemory = KindOfMemory;
    }

    public void setM2ConnectorSupported(boolean M2ConnectorSupported) {
        this.M2ConnectorSupported = M2ConnectorSupported;
    }

    public void setParalelSupported(boolean ParalelSupported) {
        this.ParalelSupported = ParalelSupported;
    }

    public void setPowerOfProcessor(String PowerOfProcessor) {
        this.PowerOfProcessor = PowerOfProcessor;
    }

    public void setPCIExpress2And3Supported(boolean PCIExpress2And3Supported) {
        this.PCIExpress2And3Supported = PCIExpress2And3Supported;
    }

    public void setCrossFireSupported(boolean CrossFireSupported) {
        this.CrossFireSupported = CrossFireSupported;
    }

    public void setSLI(boolean SLI) {
        this.SLISupport = SLI;
    }

    public void setPrice(double Price) {
        this.Price = Price;
    }

    public String getName() {
        return Name;
    }

    public double getMuchOfMemory() {
        return MuchOfMemory;
    }

    public String getKindOfMemory() {
        return KindOfMemory;
    }

    public boolean getM2ConnectorSupported() {
        return M2ConnectorSupported;
    }

    public boolean getParalelSupported() {
        return ParalelSupported;
    }

    public String getPowerOfProcessor() {
        return PowerOfProcessor;
    }

    public boolean getPCIExpress2And3Supported() {
        return PCIExpress2And3Supported;
    }

    public boolean getCrossFireSupported() {
        return CrossFireSupported;
    }

    public boolean getSLI() {
        return SLISupport;
    }

    public double getPrice() {
        return Price;
    }

}
