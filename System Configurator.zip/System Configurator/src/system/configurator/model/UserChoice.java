/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package system.configurator.model;

/**
 *
 * @author ali
 */
public class UserChoice {
    private String category;
    private String costRange;

    public UserChoice() {
    }

    
    public UserChoice(String category, String costRange) {
        this.category = category;
        this.costRange = costRange;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getCostRange() {
        return costRange;
    }

    public void setCostRange(String costRange) {
        this.costRange = costRange;
    }
    
    
}
