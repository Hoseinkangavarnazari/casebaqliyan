package system.configurator.model;

import java.io.Serializable;
import system.configurator.helpers.ScoreCalculator;
import system.configurator.users.metrics.RAMMetrics;

public class RAM implements Serializable {

    private static final long serialVersionUID = 13960921L;

    private String Name;
    private double Memory;// integer
    private boolean XMP;
    private String KindOfMemory;
    private double CountOfChannel;
    private double Price;
    private RAMMetrics ramMetrics;

    private double ramScore;

    public double getRamScore() {
        return ramScore;
    }

    public void calculateRamScore(RAMMetrics userRAMMetrics) {
        this.ramScore = ScoreCalculator.ramScoreCalculator(ramMetrics, userRAMMetrics);
    }

    public RAM() {
    }

    public RAM(String Name, double Memory, boolean XMP, String KindOfMemory, double CountOfChannel, double Price, RAMMetrics rAMMetrics) {
        this.Name = Name;
        this.Memory = Memory;
        this.XMP = XMP;
        this.KindOfMemory = KindOfMemory;
        this.CountOfChannel = CountOfChannel;
        this.Price = Price;
        this.ramMetrics = rAMMetrics;
    }

    public RAM(String Name, double Memory, boolean XMP, String KindOfMemory,
            double CountOfChannel, double Price) {
        this.Name = Name;
        this.Memory = Memory;
        this.XMP = XMP;
        this.KindOfMemory = KindOfMemory;
        this.CountOfChannel = CountOfChannel;
        this.Price = Price;
    }

    public RAMMetrics getRamMetrics() {
        return ramMetrics;
    }

    public void setRamMetrics(RAMMetrics ramMetrics) {
        this.ramMetrics = ramMetrics;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public void setMemory(double Memory) {
        this.Memory = Memory;
    }

    public void setXMP(boolean XMP) {
        this.XMP = XMP;
    }

    public void setKindOfMemory(String KindOfMemory) {
        this.KindOfMemory = KindOfMemory;
    }

    public void setCountOfChannel(double CountOfChannel) {
        this.CountOfChannel = CountOfChannel;
    }

    public void setPrice(double Price) {
        this.Price = Price;
    }

    public String getName() {
        return Name;
    }

    public double getMemory() {
        return Memory;
    }

    public boolean getXMP() {
        return XMP;
    }

    public String getKindOfMemory() {
        return KindOfMemory;
    }

    public double getCountOfChannel() {
        return CountOfChannel;
    }

    public double getPrice() {
        return Price;
    }

}
