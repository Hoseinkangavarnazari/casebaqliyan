/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package system.configurator.helpers;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;
import system.configurator.model.HardwareContainer;

/**
 *
 * @author ali
 */
public class HardwareRepositoryHelper {

    public static HardwareContainer getAllRepository() {
        File hardwareRepository = new File("hardwareRepository.data");

        if (hardwareRepository.exists()) {

            try {
                ObjectInputStream inputStream = new ObjectInputStream(
                        new FileInputStream(hardwareRepository));
                HardwareContainer hardwareContainer = (HardwareContainer) inputStream.readObject();

                return hardwareContainer;
            } catch (FileNotFoundException ex) {
                Logger.getLogger(HardwareRepositoryHelper.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(HardwareRepositoryHelper.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(HardwareRepositoryHelper.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        return new HardwareContainer();
    }
    
    public static void saveRepositoryData(HardwareContainer hardwareContainer){
        
        File hardwareRepository = new File("hardwareRepository.data");
        
        try {
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(
                    new FileOutputStream(hardwareRepository));
            
            objectOutputStream.writeObject(hardwareContainer);
        } catch (IOException ex) {
            Logger.getLogger(HardwareRepositoryHelper.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
