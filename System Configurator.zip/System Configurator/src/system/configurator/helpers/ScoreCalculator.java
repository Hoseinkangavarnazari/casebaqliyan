/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package system.configurator.helpers;

import java.util.List;
import system.configurator.model.CPU;
import system.configurator.model.GPU;
import system.configurator.model.Motherboard;
import system.configurator.model.RAM;
import system.configurator.model.Storage;
import system.configurator.users.metrics.CPUMetrics;
import system.configurator.users.metrics.GPUMetrics;
import system.configurator.users.metrics.MotherboardMetrics;
import system.configurator.users.metrics.RAMMetrics;
import system.configurator.users.metrics.StorageMetrics;
import system.configurator.users.metrics.UserMetrics;

/**
 *
 * @author ali
 */
public class ScoreCalculator {
    
    public static double gpuScoreCalculator(GPUMetrics hardwarMetrics, GPUMetrics userMetrics) {
        
        double scorePower = (hardwarMetrics.getPower() * userMetrics.getPower());
        double scoreCost = hardwarMetrics.getCost() * userMetrics.getCost();
        double scoreExtend = hardwarMetrics.getExtend() * userMetrics.getExtend();
        double scoreCompute = hardwarMetrics.getCompute() * userMetrics.getCompute();
        return scorePower + scoreCost + scoreExtend + scoreCompute;
    }
    
    public static double cpuScoreCalculator(CPUMetrics hardwarMetrics, CPUMetrics userMetrics) {
        
        double scorePower = (hardwarMetrics.getPower() * userMetrics.getPower());
        double scoreCost = hardwarMetrics.getCost() * userMetrics.getCost();
        double scoreOnboardGraphic = hardwarMetrics.getOnboardGraphic() * userMetrics.getOnboardGraphic();
        double scoreParallel = hardwarMetrics.getParallel() * userMetrics.getParallel();
        return scorePower + scoreCost + scoreOnboardGraphic + scoreParallel;
        
    }
    
    public static double ramScoreCalculator(RAMMetrics hardwarMetrics, RAMMetrics userMetrics) {
        
        double scoreSlot = (hardwarMetrics.getSlot() * userMetrics.getSlot());
        double scoreCost = hardwarMetrics.getCost() * userMetrics.getCost();
        double scoreSpace = hardwarMetrics.getSpace() * userMetrics.getSpace();
        double scoreSpeed = hardwarMetrics.getSpeed() * userMetrics.getSpeed();
        return scoreSlot + scoreCost + scoreSpeed + scoreSpace;
    }
    
    public static double motherboardScoreCalculator(MotherboardMetrics hardwarMetrics, MotherboardMetrics userMetrics) {
        
        double scorePower = (hardwarMetrics.getPower() * userMetrics.getPower());
        double scoreCost = hardwarMetrics.getCost() * userMetrics.getCost();
        double scoreExtend = hardwarMetrics.getExtend() * userMetrics.getExtend();
        
        return scorePower + scoreCost + scoreExtend;
    }
    
    public static double storageScoreCalculator(StorageMetrics hardwarMetrics, StorageMetrics userMetrics) {
        
        double scoreReliability = (hardwarMetrics.getReliability() * userMetrics.getReliability());
        double scoreCost = hardwarMetrics.getCost() * userMetrics.getCost();
        double scoreSpace = hardwarMetrics.getSpace() * userMetrics.getSpace();
        double scoreSpeed = hardwarMetrics.getSpeed() * userMetrics.getSpeed();
        return scoreReliability + scoreCost + scoreSpeed + scoreSpace;
    }
    
    public static void gpuListScoreCalculation(List<GPU> gpus, UserMetrics userMetrics) {
        
        gpus.forEach((gpu) -> {
            gpu.calculateGpuScore(userMetrics.getGpuMetrics());
        });
    }
    
    public static void cpuListScoreCalculation(List<CPU> cpus, UserMetrics userMetrics) {
        
        cpus.forEach((cpu) -> {
            cpu.calculateCpuScore(userMetrics.getCpuMetrics());
        });
    }
    
    public static void motherboardListScoreCalculation(List<Motherboard> motherboards,
             UserMetrics userMetrics) {
        
        motherboards.forEach((motherboard) -> {
            motherboard.calculateMotherboardScore(userMetrics.getMotherboardMetrics());
        });
    }
    
    public static void ramListScoreCalculation(List<RAM> rams, UserMetrics userMetrics){
        
        rams.forEach((ram) -> {
            ram.calculateRamScore(userMetrics.getRamMetrics());
        });
    }
    
    public static void storageListCalculation(List<Storage> storages, UserMetrics userMetrics){
        
        storages.forEach((storage) -> {
            storage.calculateStorageScore(userMetrics.getStorageMetrics());
        });
    }
}
