/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testfile;

import java.util.List;
import system.configurator.helpers.HardwareRepositoryHelper;
import system.configurator.model.CPU;
import system.configurator.model.GPU;
import system.configurator.model.HardwareContainer;
import system.configurator.model.Motherboard;
import system.configurator.model.RAM;
import system.configurator.model.Storage;

/**
 *
 * @author ali
 */
public class TestFile {
    
    public static void main(String[] args) {
        HardwareContainer hardwareContainer = HardwareRepositoryHelper.getAllRepository();
        
        System.out.println("#######################CPU##############################");
        List<CPU> cpus = hardwareContainer.getListOfCPU();
        cpus.forEach((cpu) -> {
            System.out.println(cpu.getName() + " " + cpu.getType());
        });
        
        System.out.println("#######################Motherboard##############################");
        List<Motherboard> motherboards = hardwareContainer.getListOMotherboards();
        motherboards.forEach((motherboard) -> {
            System.out.println(motherboard.getName() + " " + motherboard.getBios() + " " + motherboard.getKindOfMemorySupported().get(0));
        });
        
       
        System.out.println("#######################GPU##############################");
        List<GPU> gpus = hardwareContainer.getListOfGPU();
        gpus.forEach((gpu) -> {
//            if(gpu.getName().equals("K40 nvidia Tesla"))
//                gpu.getGpuMetrics().setPower(-1);
//            if(gpu.getName().equals("K80 nvidia Tesla"))
//                gpu.getGpuMetrics().setPower(-1);
//            if(gpu.getName().equals("ROG STRIX GTX 1080"))
//                gpu.getGpuMetrics().setCost(0.1);
            System.out.println(gpu.getName() + " " + gpu.getKindOfMemory());
        });
//         HardwareRepositoryHelper.saveRepositoryData(hardwareContainer);
        System.out.println("#######################RAM##############################");
        List<RAM> rams = hardwareContainer.getListOfRAM();
        rams.forEach((ram) -> {
            System.out.println(ram.getName() + " " + ram.getKindOfMemory() + " " + ram.getMemory());
            System.out.println(ram.getRamMetrics().getCost()+ " " + ram.getRamMetrics().getSlot()
                    + " " + ram.getRamMetrics().getSpace() + " " + ram.getRamMetrics().getSpeed());
        });
//        HardwareRepositoryHelper.saveRepositoryData(hardwareContainer);
        System.out.println("#######################Storage##############################");
        List<Storage> storages = hardwareContainer.getListOfStorages();
        storages.forEach((storage) -> {
            System.out.println(storage.getName() + " " + storage.getKindOfDisk());
        });
    }
}
